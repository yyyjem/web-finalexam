declare function dataViewByteOffset(value: DataView): number;
declare function dataViewByteOffset(value: unknown): never;

export = dataViewByteOffset;