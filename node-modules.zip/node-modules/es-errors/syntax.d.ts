declare const SyntaxError: SyntaxErrorConstructor;

export = SyntaxError;
