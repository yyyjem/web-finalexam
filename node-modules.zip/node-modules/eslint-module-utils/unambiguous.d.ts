import type { AST } from 'eslint';

declare function isModule(ast: AST.Program): boolean;

declare function test(content: string): boolean;

export { isModule, test }
