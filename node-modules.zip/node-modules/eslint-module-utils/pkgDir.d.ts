declare function pkgDir(cwd: string): string | null;

export default pkgDir;
