declare function moduleRequire<T>(p: string): T;

export default moduleRequire;
