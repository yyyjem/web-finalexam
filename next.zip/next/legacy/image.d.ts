import Image from '../dist/client/legacy/image'
export * from '../dist/client/legacy/image'
export default Image
