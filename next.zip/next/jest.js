module.exports = require('./dist/build/jest/jest')
