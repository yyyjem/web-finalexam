module.exports = require('./dist/client/components/navigation')
