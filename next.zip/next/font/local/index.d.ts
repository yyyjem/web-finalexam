export { default } from 'next/dist/compiled/@next/font/dist/local'
