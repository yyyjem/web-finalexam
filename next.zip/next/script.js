module.exports = require('./dist/client/script')
