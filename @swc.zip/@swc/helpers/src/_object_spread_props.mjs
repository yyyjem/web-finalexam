export { _ as default } from "../esm/_object_spread_props.js";
