export { _ as default } from "../esm/_assert_this_initialized.js";
