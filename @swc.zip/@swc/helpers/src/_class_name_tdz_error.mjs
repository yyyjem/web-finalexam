export { _ as default } from "../esm/_class_name_tdz_error.js";
