export { _ as default } from "../esm/_object_destructuring_empty.js";
