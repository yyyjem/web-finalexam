export { _ as default } from "../esm/_define_property.js";
