export { _ as default } from "../esm/_get_prototype_of.js";
