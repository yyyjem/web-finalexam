export { _ as default } from "../esm/_read_only_error.js";
