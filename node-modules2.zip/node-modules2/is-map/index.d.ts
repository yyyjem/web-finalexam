declare function isMap<K = unknown, V = unknown>(x: unknown): x is Map<K, V>;

export = isMap;