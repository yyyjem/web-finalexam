declare const x: typeof Reflect.getPrototypeOf | null;

export = x;