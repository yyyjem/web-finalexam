declare function hasProto(): boolean;

export = hasProto;
