declare function mutator(): boolean;

export = mutator;