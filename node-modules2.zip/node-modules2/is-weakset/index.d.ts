declare function isWeakSet<V extends WeakKey = object>(value: unknown): value is WeakSet<V>;

export = isWeakSet;