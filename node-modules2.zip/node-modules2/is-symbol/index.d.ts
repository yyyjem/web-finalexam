declare function isSymbol(value: unknown): value is (symbol | Symbol);

export = isSymbol;
