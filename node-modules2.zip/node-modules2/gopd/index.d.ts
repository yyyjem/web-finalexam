declare function gOPD<O extends object, K extends keyof O>(obj: O, prop: K): PropertyDescriptor | undefined;

declare const fn: typeof gOPD | undefined | null;

export = fn;