declare function isSet<V = unknown>(x: unknown): x is Set<V>;

export = isSet;
