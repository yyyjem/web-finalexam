declare function isArrayBuffer(value: unknown): value is ArrayBuffer;

export = isArrayBuffer;