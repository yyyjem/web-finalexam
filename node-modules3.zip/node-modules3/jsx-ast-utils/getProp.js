module.exports = require('./lib').getProp; // eslint-disable-line import/no-unresolved
