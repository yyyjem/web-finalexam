declare function isFinite(x: unknown): x is number | bigint;

export = isFinite;